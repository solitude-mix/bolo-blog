title: grafana配置
date: '2022-06-17 08:44:32'
updated: '2022-06-17 08:44:32'
tags: [grafana]
permalink: /articles/2022/06/17/1671071098553.html
---
1、share免登录

编辑conf目录下的default.ini

[auth.anonymous]

# enable anonymous access

enabled = true         #默认false

# specify role for unauthenticated users

org_role = Viewer    #默认Viewer

