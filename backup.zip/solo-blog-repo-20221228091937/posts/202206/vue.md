title: vue
date: '2022-06-08 10:11:00'
updated: '2022-06-08 10:11:00'
tags: [vue]
permalink: /articles/2022/06/08/1671070761926.html
---
1、vue添加和编辑对话框共用

步骤1.

首先在data中定义一个titleMap对象，和一个dialogTitle属性，titleMap和dialogTitle关系相>当于一个键值对匹配一样（通过dialogTitle匹配titleMap中的值）

titleMap对象中有两个属性，两个属性都有对应的属性值，分别表示点击方法弹出对话框的标题信息

```
titleMap : {

                addData : "添加数据",

                updateData : "修改数据"

            },

           dialogTitle : ""
```

步骤2.

通过双向数据绑定将titleMap对象，和dialogTitle属性绑定在组件上

<el-dialog :title="titleMap[dialogTitle]" :visible.sync="dialogFormVisible">

步骤3.

通过点击事件（添加或修改）去改变dialogTitle属性的值，从而达到对话框标题的切换

主要：添加和修改用的是同一个对象接收添加或者修改的参数的，所以在添加时需要对接收数据的对象进行初始化（修改不需要）

```
//添加的方法

         addData(){

            this.form = {};

            this.dialogFormVisible = true;

            this.dialogTitle = "addData";

        },

        //修改的方法

        updateData(row){

            this.dialogFormVisible = true;

            this.dialogTitle = "updateData";

            this.form = row;

        }
```

坑1：

elementui Dialog对话框第二次打开时显示的是上一次的数据问题解决

在<el-dialog>中添加v-if=‘dialogEdit’

<el-dialog :title="titleMap[dialogTitle]" :visible.sync="dialogFormVisible" v-if="dialogFormVisible">

