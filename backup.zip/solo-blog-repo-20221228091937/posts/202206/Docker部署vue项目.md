title: Docker部署vue项目
date: '2022-06-09 15:12:32'
updated: '2022-12-15 10:23:19'
tags: [Docker, vue]
permalink: /articles/2022/06/09/1671070987501.html
---
一、准备工作

1、安装docker

步骤省略.....

2、安装Nginx

* 拉取镜像

docker pull nginx:latest

* 查看镜像

docker images

* 运行镜像

docker run --name nginx-test -p 8080:80 -d nginx

```
参数说明：

        –name nginx-test：容器名称。

        -p 8080:80： 端口进行映射，将本地 8080 端口映射到容器内部的 80 端口。

        -d nginx： 设置容器在在后台一直运行。
```

3、安装node

* 拉取镜像

docker pull node:latest

* 查看镜像

docker images

* 运行镜像

docker run -i -t node /bin/bash

参数说明：

```
-i：容器的标准输入保持打开

        -t：让docker分配一个伪终端并绑定到容器的标准输入上

        -p : 端口映射 格式为[主机端口：容器端口]

        -d : 后台模式运行

        -name : 给容器的起一个名字

        -v：挂载主机的目录
```

* 查看是否安装成功

node -v

4、vue-cli安装

* npm install -g @vue/cli

二、上传文件

1、Linux服务器创建项目文件夹

mkdir docker

2、打包本地vue项目

npm run build

3、将项目中的dist文件夹、Dockerfile文件、nginx.conf文件上传到Linux服务器

三、Docker运行

1、基于上传的Dockerfile文件构建vue镜像

运行命令（注意不要少了最后的“.”）

docker build -t vue-demo .

2、基于vue-demo镜像启动容器，运行命令

docker run -p 3000:80 -d --name vueApp vue-demo

参数说明：

```
docker run 基于镜像启动一个容器

    -p 3000:80 端口映射，将宿主的3000端口映射到容器的80端口

    -d 后台方式运行

    -name 容器名，查看 Docker 进程
```

注意：1、服务器防火墙放通端口号

```
2、Dockerfile文件参考
```

# 设置基础镜像

FROM nginx

# 定义作者

MAINTAINER ztsui

# 添加时区环境变量，亚洲，上海

ENV TimeZone=Asia/Shanghai

# 使用软连接，并且将时区配置覆盖/etc/timezone

RUN ln -snf /usr/share/zoneinfo/$TimeZone /etc/localtime && echo $TimeZone > /etc/timezone

# 将dist文件中的内容复制到 /usr/share/nginx/html/ 这个目录下面

COPY dist/  /usr/share/nginx/html/

COPY nginx.conf /etc/nginx/nginx.conf

RUN echo 'echo init ok!!'

```
3、nginx.conf文件参考
```

worker_processes auto;

events {

```
worker_connections  1024;
```

}

http {

```
include       mime.types;

default_type  application/octet-stream;



sendfile        on;

keepalive_timeout  65;

client_max_body_size   20m;

server {

    listen       80;

    server_name  localhost;



    location / {

         root   /usr/share/nginx/html;

         index  index.html index.htm;

         try_files $uri $uri/ /index.html;

    }

 

    error_page   500 502 503 504  /50x.html;

        location = /50x.html {

            root   html;

    }    

}
```

}

