title: 使用Docker命令推送镜像到harbor
date: '2022-06-24 10:19:37'
updated: '2022-06-24 10:19:37'
tags: [Docker, harbor]
permalink: /articles/2022/06/24/1671071210070.html
---
1、推送镜像到harbor

1.1 准备

先拉取一个镜像下来做试验用：

docker pull nginx

1.2 标记镜像

给待推送的镜像打标记，打标记命令格式如下：

docker tag SOURCE_IMAGE[:TAG] 192.168.211.5:80/library/REPOSITORY[:TAG]

稍微解释下：

SOURCE_IMAGE[:TAG]表示当前docker已存在的某个版本的镜像

library表示的是harbor里头的某个项目名称，表示镜像推送给这个项目

注意，其中ip和端口都不要省（尤其在http协议里头）

比如我要推送nginx到harbor仓库，打的标记如下：

docker tag nginx:latest 192.168.211.5:80/library/nginx:latest

1.3 登录docker（可省）

执行以下命令

docker login 192.168.211.5:80

登出docker的命令：

docker logout

登录日志如下：

[root@localhost harbor]# docker login 192.168.211.5:80

Username: admin

Password:

WARNING! Your password will be stored unencrypted in /root/.docker/config.json.

Configure a credential helper to remove this warning. See

https://docs.docker.com/engine/reference/commandline/login/#credentials-store

Login Succeeded

1.4 推送镜像

给我的harbor推送镜像的命令格式如下：

docker push 192.168.211.5:80/library/REPOSITORY[:TAG]

看命令就知道，docker push后面的其实就是打标记的时候标记。

比如我要推送上面已经打好标记的镜像，命令如下：

docker push 192.168.211.5:80/library/nginx:latest

日志如下：

[root@localhost harbor]# docker tag nginx:latest 192.168.211.5:80/library/nginx:latest

[root@localhost harbor]# docker push 192.168.211.5:80/library/nginx:latest

The push refers to repository [192.168.211.5:80/library/nginx]

fac15b2caa0c: Pushed

f8bf5746ac5a: Pushed

d11eedadbd34: Pushed

797e583d8c50: Pushed

bf9ce92e8516: Pushed

d000633a5681: Pushed

latest: digest: sha256:6fe11397c34b973f3c957f0da22b09b7f11a4802e1db47aef54c29e2813cc125 size: 1570

