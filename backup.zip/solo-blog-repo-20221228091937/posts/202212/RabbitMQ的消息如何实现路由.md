title: RabbitMQ 的消息如何实现路由？
date: '2022-12-27 10:01:00'
updated: '2022-12-27 10:01:00'
tags: [RabbitMQ]
permalink: /articles/2022/12/27/1672106528119.html
---
# RabbitMQ 的消息如何实现路由？

**RabbitMQ 是一个基于AMQP 协议实现的分布式消息中间件。**

**AMQP 的具体工作机制是， 生产者把消息发送到RabbitMQ Broker 上的**
**Exchange 交换机上。Exchange 交换机把收到的消息根据路由规则发给绑定的队（Queue）。最后再把消息投递给订阅了这个队列的消费者，从而完成消息的异步通讯。**

![image-20221227094403671](http://zts.zts521.top/image-20221227094403671.png)

**其中，Exchange 是一个消息交换机，它里面定义了消息路由的规则，也就是这个消息路由到那个队列。**

**然后Queue 表示消息的载体，每个消息可以根据路由规则路由到一个或者多个队列里面。**

**而关于消息的路由机制，核心的组件是Exchange。它负责接收生产者的消息然后把消息路由到消息队列，而消息的路由规则由ExchangeType 和Binding 决定。**
**Binding 表示建立Queue 和Exchange 之间的绑定关系，每一个绑定关系会存在一个BindingKey。通过这种方式相当于在Exchange 中建立了一个路由关系表。**

![image-20221227094458250](http://zts.zts521.top/image-20221227094458250.png)

**生产者发送消息的时候，需要声明一个RoutingKey （路由键），Exchange 拿到RoutingKey 之后，根据RoutingKey 和路由表里面的BindingKey 进行匹配，而匹配的规则是通过ExchangeType 来决定的。**

![image-20221227094521000](http://zts.zts521.top/image-20221227094521000.png)

**在RabbitMQ 中，有三种类型的Exchange：direct ，fanout 和topic。**

* **direct： 完整匹配方式，也就是Routing key 和Binding Key 完全一致，相当于点对点的发送。**
* **fanout： 广播机制，这种方式不会基于Routing key 来匹配，而是把消息广播给绑定到当前Exchange 上的所有队列上。**
* **topic： 正则表达式匹配，根据Routing Key 使用正则表达式进行匹配，符合匹配规则的Queue 都会收到这个消息**

