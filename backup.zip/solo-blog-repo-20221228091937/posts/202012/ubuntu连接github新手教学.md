title: ubuntu连接github（新手教学）
date: '2020-12-12 09:24:00'
updated: '2022-12-13 18:25:06'
tags: [ubuntu]
permalink: /articles/2020/12/12/1670927081639.html
---
# **ubuntu连接github（新手教学）**

## **一、安装与配置**

### 1.安装

在终端执行代码，然后输入自己的密码。

```
sudo apt-get install git
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222105219269.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
**备注：**

1. 若出现：您希望继续执行吗？【Y/n】	则输入y
   图片省略……（ps：我忘记截图了┭┮﹏┭┮）
2. 若出现如下情况
   ![\[外链图片转存失败,源站可能有防盗链机制,建议将图片保存下来直接上传(img-U08xxYl6-1608605323084)(C:\Users\asus\AppData\Roaming\Typora\typora-user-images\image-20201222083214613.png)\]](https://img-blog.csdnimg.cn/20201222105312545.png#pic_center)
   则执行以下代码，进行update。
   
   ```
   sudo apt-get update
   ```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222105528801.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)

- **查看是否安装成功**	
  运行代码

```
git --version
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222105648630.png#pic_center)

### **2.配置**

- **（1）创建项目的SSH key**
  
  ```
  ssh-keygen -t rsa -C "你的邮箱"
  ```
  
  三次点击回车就好了。
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222105757545.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
- **进入你的存储密钥的路径**
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222105836363.png#pic_center)
  这就是SSH Key的秘钥对，id_rsa是私钥，不能泄露，id_rsa.pub是公钥，可以告诉任何人
- **执行代码**
  
  ```
  gedit id_rsa.pub
  ```
  
  **打开公钥，复制其内容**
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222105929497.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
- **(2)登录[github](https://github.com/)注册或登录账号，打开settings的SSH Keys页面，点New SSH Key，填上任意Title，在Key文本框里粘贴id_rsa.pub文件的内容，点“Add Key”，你就可以看到已经添加的Key**
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110035181.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70)
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/2020122211003560.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70)
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110035238.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70)
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110035192.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70)
- **（3）接下来要做的是设置GitHub用户的配置细节。为此，使用下列两个命令，把“user_name”换成你的GitHub用户名，把“email_id”换成你用来创建GitHub帐户的电子邮件ID。**

```
git config --global user.name "user_name"
git config --global user.email "email_id"
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110148546.png#pic_center)
执行如下代码可以查看配置后的user.name和user.email

```
git config user.name

git config user.email
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110253461.png#pic_center)

## 二、Git的使用

### （1）在GitHub上创建仓库

- **登陆GitHub，然后找到“New”按钮，创建一个新的仓库，如下图**
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110344988.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
- **博主在这里创建了一个mytest1的仓库（记住这个仓库名字后续会用到！！），如下图所示。**
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201223163006178.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
- **复制你的HTTPS地址，如下图所示。**
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20201223163547503.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)

### **（2）创建本地仓库**

进入你的桌面创建一个文件夹。该文件夹将充当本地仓库（请注意：仓库名称应该与github上的仓库名称一样）。使用下列命令：

```
git init mytest1
```

如果仓库成功创建，那么你会看到下列行：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110701918.png#pic_center)

这一行可能不一样，具体取决于你的系统。

所以这里，"mytest1"是创建的文件夹，"init"使该文件夹成为github仓库。

打开创建的文件夹：

```
cd mytest1
```

### （3）创建一个文本类文件

现在创建一个text文件，输入一些文本，比如“hello github”。例子如下：

```
gedit text.txt
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110845274.png#pic_center)
可以使用其他任何文本编辑器，我使用gedit。text文件的内容如下：

```
hello github
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222110923684.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)

### （4）**将仓库文件添加到索引**

这是个重要的步骤。这一步，我们把需要推送到GitHub网站的所有内容添加到索引中。这些内容可能是你首次添加到仓库中的文本文件或程序，也可能是添加已经存在，但出现了一些变更的文件（更新颖的版本/经过更新的版本）。

我们不妨再创建含有一个简单的C程序的另一个文件，命名为sample.c。

执行如下代码：

```
gedit sample.c
```

如下图所示：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222111005989.png#pic_center)
文件内容如下：

```c
#include<stdio.h> 
int main()
{
	printf("hello world"); 
	return 0;
}
```

如下图所示：

![\[外链图片转存失败,源站可能有防盗链机制,建议将图片保存下来直接上传(img-gTVVDjOb-1608605323160)(C:\Users\asus\AppData\Roaming\Typora\typora-user-images\image-20201222095621718.png)\]](https://img-blog.csdnimg.cn/20201222111124407.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
所以，现在我们有了2个文件：text.txt和sample.c，使用下列两个命令，添加到索引中：

```
git add text.txt

git add smaple.c
```

### （5）提交所作的变更

首先初始化当前目录为版本库，添加远程仓库并与本地同步，输入如下图命令

```
git init
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222111221826.png#pic_center)
一旦所有文件添加完毕，我们就可以提交了。这意味着，我们最终敲定了要添加及/或变更的内容，现在它们已准备好上传到我们的仓库。使用该命令：

```
git commit -m "message"
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/2020122211132266.png#pic_center)
上述命令中的“message”可能是任何简单的信息，比如“my first commit”或“edit in readme”等等。

### （6）连接仓库

我们可以将本地仓库的内容推送到你github仓库。使用该命令，连接到github上的仓库：

```
git remote add origin https://github.com/user_name/Mytest.git
```

**重要告知：在运行该命令之前，确保把路径中的“user_name”和“Mytest”换成了你的github用户名和文件夹！（就是之前在github上复制的HTTPS）**

### （7）**将本地仓库中的文件推送到github仓库**

最后一步是，使用如下所示命令，将本地仓库的内容推送到远程主机仓库（GitHub）：

```
git push origin master
```

输入登录用户信息[用户名和密码] 。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222111358108.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)

### （8）github查看上传文件

登录你的github中选择你所创建的仓库，选择如下图所示的分支。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222111444369.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)

你会两个文件：test.txt和sample.c已被上传，所有人都能看见。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222111623490.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)
点击sample.c文件，可以查看内容。
![在这里插入图片描述](https://img-blog.csdnimg.cn/20201222111640875.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NhcHBoaXJlNDE=,size_16,color_FFFFFF,t_70#pic_center)

## 三、总结

第一次写，有什么不对的或者缺少的地方欢迎探讨，大佬请绕道（我才刚开始学，不想被打击到┭┮﹏┭┮）

